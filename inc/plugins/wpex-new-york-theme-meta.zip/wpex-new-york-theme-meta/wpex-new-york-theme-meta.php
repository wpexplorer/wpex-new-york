<?php
/*
Plugin Name: WPEX New York Theme Meta
Plugin URI: http://www.wpexplorer.com
Description: Adds custom meta options for the New York theme.
Author: WPExplorer
Version: 1.0
Author URI: https://www.wpexplorer.com/
Text Domain: wpex-nyt-meta
*/

// Prevent direct file access
if ( ! defined ( 'ABSPATH' ) ) {
	exit;
}

// Define theme name
if ( ! defined( 'WPEX_THEME_NAME' ) ) {
	define( 'WPEX_THEME_NAME', 'New York' );
}

// Load text domain
function wpex_nyt_meta_text_domain() {
    load_plugin_textdomain( 'wpex-nyt-meta', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'wpex_nyt_meta_text_domain' );


// Define dir
$dir = plugin_dir_path( __FILE__ );

require_once( $dir . 'inc/gallery-metabox.php' );
require_once( $dir . 'inc/term-thumbnails.php' );
require_once( $dir . 'inc/meta-pages.php' );
require_once( $dir . 'inc/meta-posts.php' );