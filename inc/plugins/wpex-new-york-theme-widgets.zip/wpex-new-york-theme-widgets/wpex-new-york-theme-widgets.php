<?php
/*
Plugin Name: WPEX New York Theme Widgets
Plugin URI: https://www.wpexplorer.com
Description: Custom widgets for the New York theme.
Author: WPExplorer
Version: 1.2.2
Author URI: https://www.wpexplorer.com
Text Domain: wpex-nyt-widgets
*/

// Prevent direct file access
if ( ! defined ( 'ABSPATH' ) ) {
	exit;
}

// Define theme name
if ( ! defined( 'WPEX_THEME_NAME' ) ) {
	define( 'WPEX_THEME_NAME', 'New York' );
}

// Load text domain
function wpex_nyt_widgets_text_domain() {
    load_plugin_textdomain( 'wpex-nyt-widgets', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'wpex_nyt_widgets_text_domain' );

// Require widgets classes
function wpex_nyt_widgets_require_widgets() {

	$dir = plugin_dir_path( __FILE__ ) . 'widgets/';

	$widgets = apply_filters( 'wpex_theme_widgets', array(
		'about',
		'posts-thumbnails',
		'comments-avatar',
	) );

	foreach ( $widgets as $widget ) {
		$widget_file = $dir . $widget .'.php';
		if ( file_exists( $widget_file ) ) {
			require_once( $widget_file );
	   }
	}

}
add_action( 'widgets_init', 'wpex_nyt_widgets_require_widgets' );