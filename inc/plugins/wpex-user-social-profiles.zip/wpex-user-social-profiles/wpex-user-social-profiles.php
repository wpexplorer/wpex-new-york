<?php
/*
Plugin Name: WPEX User Social Profiles
Plugin URI: http://www.wpexplorer.com
Description: This plugin adds social profile fields to the user admin screen to be used on certain themes primarily for author boxes.
Version: 1.1
Author: WPExplorer
Author URI: http://www.wpexplorer.com
License: GNU General Public License version 2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

if ( ! defined( 'WPEX_USER_SOCIAL_PROFILES_PLUGIN_VERSION' ) ) {
	define( 'WPEX_USER_SOCIAL_PROFILES_PLUGIN_VERSION', '1.0' );
}

if ( ! class_exists( 'WPEX_User_Social_Profiles' ) ) {

	class WPEX_User_Social_Profiles {


		/**
		 * Main Constructor
		 *
		 * @since  1.0
		 * @access public
		 */
		public function __construct() {
			require_once( plugin_dir_path( __FILE__ ) .'/inc/updates.php' );
			add_filter( 'user_contactmethods', array( 'WPEX_User_Social_Profiles', 'user_contactmethods' ) );
		}

		/**
		 * Adds new contact methods
		 *
		 * @since  1.0
		 * @access public
		 */
		public function user_contactmethods( $contactmethods ) {

			// Add Twitter
			if ( ! isset( $contactmethods['wpex_twitter'] ) ) {
				$contactmethods['wpex_twitter'] = 'Twitter';
			}

			// Add Facebook
			if ( ! isset( $contactmethods['wpex_facebook'] ) ) {
				$contactmethods['wpex_facebook'] = 'Facebook';
			}

			// Add LinkedIn
			if ( ! isset( $contactmethods['wpex_linkedin'] ) ) {
				$contactmethods['wpex_linkedin'] = 'LinkedIn';
			}

			// Add Pinterest
			if ( ! isset( $contactmethods['wpex_pinterest'] ) ) {
				$contactmethods['wpex_pinterest'] = 'Pinterest';
			}

			// Add Pinterest
			if ( ! isset( $contactmethods['wpex_instagram'] ) ) {
				$contactmethods['wpex_instagram'] = 'Instagram';
			}

			// Return contactmethods
			return $contactmethods;

		}

	}

}
new WPEX_User_Social_Profiles;